import Layout from '../components/Layout';
import { BookOpen, Users, CalendarDays } from 'lucide-react';
import { Link } from 'react-router-dom';

function Dashboard() {
  const user = JSON.parse(localStorage.getItem('user'));

  const cards = [
    {
      title: 'Resource Hub',
      description: 'Upload, browse, and download notes and question papers',
      icon: BookOpen,
      link: '/resources'
    },
    {
      title: 'Team Finder',
      description: 'Post projects, find teammates, get AI-matched collaborators',
      icon: Users,
      link: '/projects'
    },
    {
      title: 'Events',
      description: 'Discover workshops, hackathons, and register in one click',
      icon: CalendarDays,
      link: '/events'
    }
  ];

  return (
    <Layout>
      <div style={{ marginBottom: '32px' }}>
        <h1 style={{ fontSize: '28px', marginBottom: '4px' }}>
          Welcome back, {user?.name?.split(' ')[0] || 'Student'}
        </h1>
        <p style={{ color: 'var(--color-text-muted)', fontSize: '15px' }}>
          {user?.department} · {user?.role}
        </p>
      </div>

      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))',
        gap: '20px'
      }}>
        {cards.map((card) => {
          const Icon = card.icon;
          return (
            <Link
              key={card.title}
              to={card.link}
              style={{
                textDecoration: 'none',
                color: 'inherit',
                background: 'var(--color-surface)',
                border: '1px solid var(--color-border)',
                borderRadius: '12px',
                padding: '24px'
              }}
            >
              <div style={{
                width: '40px',
                height: '40px',
                borderRadius: '8px',
                background: '#FFF1E7',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                marginBottom: '16px'
              }}>
                <Icon size={20} color="var(--color-accent)" />
              </div>
              <h3 style={{ fontSize: '16px', marginBottom: '6px' }}>{card.title}</h3>
              <p style={{ fontSize: '13px', color: 'var(--color-text-muted)', lineHeight: '1.5' }}>
                {card.description}
              </p>
            </Link>
          );
        })}
      </div>
    </Layout>
  );
}

export default Dashboard;