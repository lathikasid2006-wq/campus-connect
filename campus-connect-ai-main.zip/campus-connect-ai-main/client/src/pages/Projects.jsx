import { useState, useEffect } from 'react';
import axios from 'axios';
import Layout from '../components/Layout';
import { Plus, Users, Sparkles, UserPlus, Mail, CheckCircle2, Inbox } from 'lucide-react';

function Projects() {
  const [projects, setProjects] = useState([]);
  const [formData, setFormData] = useState({ title: '', description: '', requiredSkills: '' });
  const [message, setMessage] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [recommendations, setRecommendations] = useState({});
  const [requestStatuses, setRequestStatuses] = useState({});
  const [loadingRec, setLoadingRec] = useState(null);
  const [myInvites, setMyInvites] = useState([]);
  const [notifications, setNotifications] = useState([]);
  const [projectRequests, setProjectRequests] = useState({});
  const [showRequests, setShowRequests] = useState({});

  const user = JSON.parse(localStorage.getItem('user'));

  const fetchProjects = async () => {
    try {
      const res = await axios.get('http://localhost:5000/api/projects');
      setProjects(res.data);
    } catch (err) {
      console.error('Failed to load projects', err);
    }
  };

  const fetchMyInvites = async () => {
    try {
      const res = await axios.get(`http://localhost:5000/api/projects/invites/${user.id}`);
      setMyInvites(res.data);
    } catch (err) {
      console.error('Failed to load invites', err);
    }
  };

  const fetchNotifications = async () => {
    try {
      const res = await axios.get(`http://localhost:5000/api/projects/notifications/${user.id}`);
      setNotifications(res.data);
    } catch (err) {
      console.error('Failed to load notifications', err);
    }
  };

  const dismissNotification = async (requestId) => {
    try {
      await axios.put(`http://localhost:5000/api/projects/notifications/${requestId}/seen`);
      setNotifications(notifications.filter(n => n._id !== requestId));
    } catch (err) {
      console.error('Failed to dismiss notification', err);
    }
  };

  useEffect(() => {
    fetchProjects();
    fetchMyInvites();
    fetchNotifications();
  }, []);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleCreate = async (e) => {
    e.preventDefault();
    setMessage('');
    try {
      await axios.post('http://localhost:5000/api/projects', {
        title: formData.title,
        description: formData.description,
        requiredSkills: formData.requiredSkills.split(',').map(s => s.trim()),
        postedBy: user.id
      });
      setMessage('Project posted successfully');
      setFormData({ title: '', description: '', requiredSkills: '' });
      setShowForm(false);
      fetchProjects();
    } catch (err) {
      setMessage('Failed to post project');
    }
  };

  const handleJoin = async (projectId) => {
    try {
      await axios.post(`http://localhost:5000/api/projects/${projectId}/join`, {
        studentId: user.id
      });
      alert('Join request sent!');
    } catch (err) {
      alert(err.response?.data?.message || 'Failed to send request');
    }
  };

  const fetchRequestStatuses = async (projectId) => {
    try {
      const res = await axios.get(`http://localhost:5000/api/projects/${projectId}/requests`);
      const map = {};
      res.data.forEach((r) => {
        map[r.student._id] = r.status;
      });
      setRequestStatuses((prev) => ({ ...prev, [projectId]: map }));
      return res.data;
    } catch (err) {
      console.error('Failed to load request statuses', err);
      return [];
    }
  };

  const handleInvite = async (projectId, studentId) => {
    try {
      await axios.post(`http://localhost:5000/api/projects/${projectId}/invite`, {
        studentId
      });
      setRequestStatuses((prev) => ({
        ...prev,
        [projectId]: { ...prev[projectId], [studentId]: 'pending' }
      }));
    } catch (err) {
      alert(err.response?.data?.message || 'Failed to send invite');
    }
  };

  const handleShowRecommendations = async (projectId) => {
    setLoadingRec(projectId);
    try {
      const res = await axios.get(`http://localhost:5000/api/projects/${projectId}/recommend`);
      setRecommendations({ ...recommendations, [projectId]: res.data.recommendations });
      await fetchRequestStatuses(projectId);
    } catch (err) {
      console.error('Failed to load recommendations', err);
    } finally {
      setLoadingRec(null);
    }
  };

  const handleInviteResponse = async (requestId, status) => {
    try {
      await axios.put(`http://localhost:5000/api/projects/requests/${requestId}`, { status });
      setMyInvites(myInvites.filter(inv => inv._id !== requestId));
    } catch (err) {
      alert('Failed to respond to invite');
    }
  };

  const handleToggleRequests = async (projectId) => {
    const isOpen = showRequests[projectId];
    if (isOpen) {
      setShowRequests((prev) => ({ ...prev, [projectId]: false }));
      return;
    }
    try {
      const res = await axios.get(`http://localhost:5000/api/projects/${projectId}/requests`);
      setProjectRequests((prev) => ({ ...prev, [projectId]: res.data }));
      setShowRequests((prev) => ({ ...prev, [projectId]: true }));
    } catch (err) {
      console.error('Failed to load requests', err);
    }
  };

  const handleRequestDecision = async (projectId, requestId, status) => {
    try {
      await axios.put(`http://localhost:5000/api/projects/requests/${requestId}`, { status });
      const res = await axios.get(`http://localhost:5000/api/projects/${projectId}/requests`);
      setProjectRequests((prev) => ({ ...prev, [projectId]: res.data }));
      if (recommendations[projectId]) {
        await fetchRequestStatuses(projectId);
      }
    } catch (err) {
      alert('Failed to update request');
    }
  };

  const inputStyle = {
    width: '100%',
    padding: '10px 12px',
    borderRadius: '8px',
    border: '1px solid var(--color-border)',
    fontSize: '14px',
    marginBottom: '14px'
  };

  const renderInviteAction = (projectId, studentId) => {
    const status = requestStatuses[projectId]?.[studentId];

    if (status === 'accepted') {
      return (
        <span style={{ display: 'flex', alignItems: 'center', gap: '4px', fontSize: '12px', color: 'var(--color-success)', fontWeight: 700 }}>
          <CheckCircle2 size={13} />
          Joined
        </span>
      );
    }
    if (status === 'pending') {
      return (
        <span style={{ fontSize: '12px', color: 'var(--color-text-muted)', fontWeight: 600 }}>
          Pending
        </span>
      );
    }
    if (status === 'rejected') {
      return (
        <span style={{ fontSize: '12px', color: 'var(--color-danger)', fontWeight: 600 }}>
          Declined
        </span>
      );
    }
    return (
      <button
        onClick={() => handleInvite(projectId, studentId)}
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: '4px',
          padding: '5px 10px',
          border: '1px solid var(--color-accent)',
          borderRadius: '6px',
          background: 'transparent',
          color: 'var(--color-accent)',
          fontSize: '12px',
          fontWeight: 600
        }}
      >
        <UserPlus size={12} />
        Invite
      </button>
    );
  };

  return (
    <Layout>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
        <div>
          <h1 style={{ fontSize: '24px', marginBottom: '4px' }}>Team Finder</h1>
          <p style={{ color: 'var(--color-text-muted)', fontSize: '14px' }}>
            Post a project or find teammates with AI-matched skills
          </p>
        </div>
        <button
          onClick={() => setShowForm(!showForm)}
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '8px',
            padding: '10px 16px',
            background: 'var(--color-accent)',
            color: '#fff',
            border: 'none',
            borderRadius: '8px',
            fontWeight: 600,
            fontSize: '14px'
          }}
        >
          <Plus size={16} />
          Post a Project
        </button>
      </div>

      {notifications.length > 0 && (
        <div style={{ marginBottom: '24px' }}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
            {notifications.map((n) => (
              <div key={n._id} style={{
                background: n.status === 'accepted' ? '#EBFBEE' : '#FFF5F5',
                border: `1px solid ${n.status === 'accepted' ? '#B2F2BB' : '#FFC9C9'}`,
                borderRadius: '10px',
                padding: '12px 16px',
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center'
              }}>
                <span style={{ fontSize: '13px' }}>
                  {n.status === 'accepted'
                    ? `Your request to join "${n.project?.title}" was accepted! 🎉`
                    : `Your request to join "${n.project?.title}" was declined.`}
                </span>
                <button
                  onClick={() => dismissNotification(n._id)}
                  style={{ fontSize: '12px', background: 'none', border: 'none', color: 'var(--color-text-muted)', cursor: 'pointer' }}
                >
                  Dismiss
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {myInvites.length > 0 && (
        <div style={{ marginBottom: '24px' }}>
          <h3 style={{ fontSize: '14px', marginBottom: '10px', color: 'var(--color-text-muted)' }}>
            Your invitations
          </h3>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
            {myInvites.map((inv) => (
              <div key={inv._id} style={{
                background: '#FFF1E7',
                border: '1px solid #FFD9B8',
                borderRadius: '10px',
                padding: '14px 16px',
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center'
              }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                  <Mail size={16} color="var(--color-accent)" />
                  <span style={{ fontSize: '13px' }}>
                    You've been invited to join <strong>{inv.project?.title}</strong>
                  </span>
                </div>
                <div style={{ display: 'flex', gap: '8px' }}>
                  <button
                    onClick={() => handleInviteResponse(inv._id, 'accepted')}
                    style={{
                      padding: '6px 14px',
                      border: 'none',
                      borderRadius: '6px',
                      background: 'var(--color-success)',
                      color: '#fff',
                      fontSize: '12px',
                      fontWeight: 600
                    }}
                  >
                    Accept
                  </button>
                  <button
                    onClick={() => handleInviteResponse(inv._id, 'rejected')}
                    style={{
                      padding: '6px 14px',
                      border: '1px solid var(--color-border)',
                      borderRadius: '6px',
                      background: 'transparent',
                      fontSize: '12px'
                    }}
                  >
                    Decline
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {showForm && (
        <div style={{
          background: 'var(--color-surface)',
          border: '1px solid var(--color-border)',
          borderRadius: '12px',
          padding: '20px',
          marginBottom: '24px',
          maxWidth: '480px'
        }}>
          <h3 style={{ fontSize: '15px', marginBottom: '16px' }}>New Project</h3>
          <form onSubmit={handleCreate}>
            <input
              name="title"
              placeholder="Project title"
              value={formData.title}
              onChange={handleChange}
              required
              style={inputStyle}
            />
            <textarea
              name="description"
              placeholder="Description"
              value={formData.description}
              onChange={handleChange}
              required
              rows={3}
              style={{ ...inputStyle, resize: 'vertical' }}
            />
            <input
              name="requiredSkills"
              placeholder="Required skills (comma separated)"
              value={formData.requiredSkills}
              onChange={handleChange}
              required
              style={inputStyle}
            />
            {message && <p style={{ fontSize: '13px', marginBottom: '12px' }}>{message}</p>}
            <button
              type="submit"
              style={{
                width: '100%',
                padding: '10px',
                background: 'var(--color-accent)',
                color: '#fff',
                border: 'none',
                borderRadius: '8px',
                fontWeight: 600,
                fontSize: '14px'
              }}
            >
              Post Project
            </button>
          </form>
        </div>
      )}

      <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
        {projects.length === 0 && (
          <p style={{ color: 'var(--color-text-muted)', fontSize: '14px' }}>No projects posted yet.</p>
        )}
        {projects.map((p) => (
          <div key={p._id} style={{
            background: 'var(--color-surface)',
            border: '1px solid var(--color-border)',
            borderRadius: '12px',
            padding: '20px'
          }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'start' }}>
              <div style={{ flex: 1 }}>
                <h3 style={{ fontSize: '16px', marginBottom: '6px' }}>{p.title}</h3>
                <p style={{ fontSize: '13px', color: 'var(--color-text-muted)', marginBottom: '10px' }}>
                  Posted by {p.postedBy?.name} · {p.postedBy?.department}
                </p>
                <p style={{ fontSize: '14px', marginBottom: '12px' }}>{p.description}</p>
                <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap' }}>
                  {p.requiredSkills.map((skill) => (
                    <span key={skill} style={{
                      fontSize: '12px',
                      background: '#F1F3F5',
                      padding: '4px 10px',
                      borderRadius: '6px',
                      color: 'var(--color-text)'
                    }}>
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', minWidth: '160px' }}>
                {p.postedBy?._id !== user.id && (
                  <button
                    onClick={() => handleJoin(p._id)}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      gap: '6px',
                      padding: '8px 14px',
                      border: '1px solid var(--color-border)',
                      borderRadius: '8px',
                      background: 'transparent',
                      fontSize: '13px'
                    }}
                  >
                    <Users size={14} />
                    Request to Join
                  </button>
                )}
                {p.postedBy?._id === user.id && (
                  <>
                    <button
                      onClick={() => handleShowRecommendations(p._id)}
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        gap: '6px',
                        padding: '8px 14px',
                        border: '1px solid #FFD9B8',
                        borderRadius: '8px',
                        background: '#FFF1E7',
                        color: 'var(--color-accent)',
                        fontSize: '13px',
                        fontWeight: 600
                      }}
                    >
                      <Sparkles size={14} />
                      {loadingRec === p._id ? 'Matching...' : 'AI Match'}
                    </button>
                    <button
                      onClick={() => handleToggleRequests(p._id)}
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        gap: '6px',
                        padding: '8px 14px',
                        border: '1px solid var(--color-border)',
                        borderRadius: '8px',
                        background: 'transparent',
                        fontSize: '13px',
                        fontWeight: 600
                      }}
                    >
                      <Inbox size={14} />
                      {showRequests[p._id] ? 'Hide Requests' : 'View Requests'}
                    </button>
                  </>
                )}
              </div>
            </div>

            {recommendations[p._id] && (
              <div style={{ marginTop: '16px', paddingTop: '16px', borderTop: '1px solid var(--color-border)' }}>
                <h4 style={{ fontSize: '13px', marginBottom: '10px', color: 'var(--color-text-muted)' }}>
                  AI-recommended teammates
                </h4>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                  {recommendations[p._id].map((rec) => (
                    <div key={rec.id} style={{
                      display: 'flex',
                      justifyContent: 'space-between',
                      alignItems: 'center',
                      padding: '8px 12px',
                      background: 'var(--color-bg)',
                      borderRadius: '8px'
                    }}>
                      <span style={{ fontSize: '13px', fontWeight: 500 }}>{rec.name}</span>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                        <span style={{
                          fontSize: '12px',
                          fontWeight: 700,
                          color: rec.matchPercentage > 50 ? 'var(--color-success)' : 'var(--color-text-muted)'
                        }}>
                          {rec.matchPercentage}% match
                        </span>
                        {renderInviteAction(p._id, rec.id)}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {showRequests[p._id] && (
              <div style={{ marginTop: '16px', paddingTop: '16px', borderTop: '1px solid var(--color-border)' }}>
                <h4 style={{ fontSize: '13px', marginBottom: '10px', color: 'var(--color-text-muted)' }}>
                  Join requests
                </h4>
                {(!projectRequests[p._id] || projectRequests[p._id].length === 0) && (
                  <p style={{ fontSize: '13px', color: 'var(--color-text-muted)' }}>No join requests yet.</p>
                )}
                <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                  {projectRequests[p._id]?.map((req) => (
                    <div key={req._id} style={{
                      display: 'flex',
                      justifyContent: 'space-between',
                      alignItems: 'center',
                      padding: '10px 12px',
                      background: 'var(--color-bg)',
                      borderRadius: '8px'
                    }}>
                      <div>
                        <span style={{ fontSize: '13px', fontWeight: 500 }}>{req.student?.name}</span>
                        <span style={{ fontSize: '12px', color: 'var(--color-text-muted)', marginLeft: '8px' }}>
                          {req.student?.department}
                        </span>
                      </div>
                      {req.status === 'pending' ? (
                        <div style={{ display: 'flex', gap: '8px' }}>
                          <button
                            onClick={() => handleRequestDecision(p._id, req._id, 'accepted')}
                            style={{
                              padding: '5px 12px',
                              border: 'none',
                              borderRadius: '6px',
                              background: 'var(--color-success)',
                              color: '#fff',
                              fontSize: '12px',
                              fontWeight: 600
                            }}
                          >
                            Accept
                          </button>
                          <button
                            onClick={() => handleRequestDecision(p._id, req._id, 'rejected')}
                            style={{
                              padding: '5px 12px',
                              border: '1px solid var(--color-border)',
                              borderRadius: '6px',
                              background: 'transparent',
                              fontSize: '12px'
                            }}
                          >
                            Reject
                          </button>
                        </div>
                      ) : req.status === 'accepted' ? (
                        <span style={{ fontSize: '12px', color: 'var(--color-success)', fontWeight: 700 }}>Accepted</span>
                      ) : (
                        <span style={{ fontSize: '12px', color: 'var(--color-danger)', fontWeight: 700 }}>Rejected</span>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </Layout>
  );
}

export default Projects;