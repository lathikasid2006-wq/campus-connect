import { useState } from 'react';
import axios from 'axios';
import Layout from '../components/Layout';
import { Upload, Download, FileText, Search } from 'lucide-react';

function Resources() {
  const [formData, setFormData] = useState({ title: '', subject: '', semester: '' });
  const [file, setFile] = useState(null);
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState(null);
  const [searching, setSearching] = useState(false);
  const [allResources, setAllResources] = useState([]);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleUpload = async (e) => {
    e.preventDefault();
    setMessage('');

    if (!file) {
      setMessage('Please select a file to upload');
      return;
    }

    const data = new FormData();
    data.append('title', formData.title);
    data.append('subject', formData.subject);
    data.append('semester', formData.semester);
    data.append('file', file);

    setLoading(true);
    try {
      await axios.post('http://localhost:5000/api/resources/upload', data, {
        headers: { 'Content-Type': 'multipart/form-data' }
      });
      setMessage('Uploaded Successfully');
      setFormData({ title: '', subject: '', semester: '' });
      setFile(null);
      document.getElementById('fileInput').value = '';
    } catch (err) {
      setMessage('Upload failed');
    } finally {
      setLoading(false);
    }
  };

  const handleDownload = (id) => {
    window.open(`http://localhost:5000/api/resources/download/${id}`, '_blank');
  };

  const handleSearch = async (e) => {
    e.preventDefault();
    if (!searchQuery.trim()) {
      setSearchResults(null);
      return;
    }
    setSearching(true);
    try {
      // fetch full resource list once (needed to get fileName/subject for display)
      const listRes = await axios.get('http://localhost:5000/api/resources');
      setAllResources(listRes.data);

      const res = await axios.post('http://localhost:5000/api/resources/search', {
        query: searchQuery
      });

      const ranked = res.data.recommendations
        .filter(r => r.matchPercentage > 0)
        .map(r => {
          const full = listRes.data.find(res2 => res2._id === r.id);
          return full;
        })
        .filter(Boolean);

      setSearchResults(ranked);
    } catch (err) {
      console.error('Search failed', err);
    } finally {
      setSearching(false);
    }
  };

  const inputStyle = {
    width: '100%',
    padding: '10px 12px',
    borderRadius: '8px',
    border: '1px solid var(--color-border)',
    fontSize: '14px',
    marginBottom: '14px'
  };

  return (
    <Layout>
      <h1 style={{ fontSize: '24px', marginBottom: '4px' }}>Resource Hub</h1>
      <p style={{ color: 'var(--color-text-muted)', fontSize: '14px', marginBottom: '20px' }}>
        Search AI-recommended notes, question papers, and study materials
      </p>

      {/* Search bar */}
      <form onSubmit={handleSearch} style={{ display: 'flex', gap: '10px', marginBottom: '24px', maxWidth: '520px' }}>
        <input
          type="text"
          placeholder="Search topics, e.g. OS, ML, DSA..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          style={{ ...inputStyle, marginBottom: 0 }}
        />
        <button
          type="submit"
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '6px',
            padding: '10px 16px',
            background: 'var(--color-accent)',
            color: '#fff',
            border: 'none',
            borderRadius: '8px',
            fontWeight: 600,
            fontSize: '14px',
            whiteSpace: 'nowrap'
          }}
        >
          <Search size={16} />
          {searching ? 'Searching...' : 'Search'}
        </button>
      </form>

      {/* Search results */}
      {searchResults && (
        <div style={{ marginBottom: '28px' }}>
          {searchResults.length === 0 ? (
            <p style={{ fontSize: '14px', color: 'var(--color-text-muted)' }}>
              No matching resources found for "{searchQuery}".
            </p>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
              {searchResults.map((r) => (
                <div key={r._id} style={{
                  background: 'var(--color-surface)',
                  border: '1px solid var(--color-border)',
                  borderRadius: '10px',
                  padding: '14px 16px',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between'
                }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                    <div style={{
                      width: '36px',
                      height: '36px',
                      borderRadius: '8px',
                      background: '#FFF1E7',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center'
                    }}>
                      <FileText size={18} color="var(--color-accent)" />
                    </div>
                    <div>
                      <p style={{ fontSize: '14px', fontWeight: 600, margin: 0 }}>{r.title}</p>
                      <p style={{ fontSize: '12px', color: 'var(--color-text-muted)', margin: 0 }}>
                        {r.subject} {r.semester && `· Sem ${r.semester}`}
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={() => handleDownload(r._id)}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '6px',
                      padding: '8px 12px',
                      border: '1px solid var(--color-border)',
                      borderRadius: '8px',
                      background: 'transparent',
                      fontSize: '13px'
                    }}
                  >
                    <Download size={14} />
                    Download
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Upload form */}
      <div style={{
        background: 'var(--color-surface)',
        border: '1px solid var(--color-border)',
        borderRadius: '12px',
        padding: '20px',
        maxWidth: '380px'
      }}>
        <h3 style={{ fontSize: '15px', marginBottom: '16px' }}>Upload a resource</h3>
        <form onSubmit={handleUpload}>
          <input
            name="title"
            placeholder="Title (e.g. DSA Unit 1)"
            value={formData.title}
            onChange={handleChange}
            required
            style={inputStyle}
          />
          <input
            name="subject"
            placeholder="Subject"
            value={formData.subject}
            onChange={handleChange}
            required
            style={inputStyle}
          />
          <input
            name="semester"
            placeholder="Semester"
            value={formData.semester}
            onChange={handleChange}
            style={inputStyle}
          />
          <input
            id="fileInput"
            type="file"
            accept=".pdf"
            onChange={(e) => setFile(e.target.files[0])}
            required
            style={{ marginBottom: '16px', fontSize: '13px' }}
          />
          {message && (
            <p style={{
              fontSize: '13px',
              color: message.includes('Success') ? 'var(--color-success)' : 'var(--color-danger)',
              marginBottom: '12px'
            }}>
              {message}
            </p>
          )}
          <button
            type="submit"
            disabled={loading}
            style={{
              width: '100%',
              padding: '10px',
              background: 'var(--color-accent)',
              color: '#fff',
              border: 'none',
              borderRadius: '8px',
              fontWeight: 600,
              fontSize: '14px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '8px'
            }}
          >
            <Upload size={16} />
            {loading ? 'Uploading...' : 'Upload'}
          </button>
        </form>
      </div>
    </Layout>
  );
}

export default Resources;