import { useState, useEffect } from 'react';
import axios from 'axios';
import Layout from '../components/Layout';
import { Plus, CalendarDays, ExternalLink, Sparkles, MapPin } from 'lucide-react';

function Events() {
  const [events, setEvents] = useState([]);
  const [recommendations, setRecommendations] = useState([]);
  const [formData, setFormData] = useState({ title: '', description: '', domain: '', department: '', date: '', time: '', venue: '', registrationLink: '', sourceName: '' });
  const [isExternal, setIsExternal] = useState(false);
  const [message, setMessage] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [registeredIds, setRegisteredIds] = useState([]);

  const user = JSON.parse(localStorage.getItem('user'));

  const fetchEvents = async () => {
    try {
      const res = await axios.get('http://localhost:5000/api/events');
      setEvents(res.data);
    } catch (err) {
      console.error('Failed to load events', err);
    }
  };

  const fetchRecommendations = async () => {
    try {
      const res = await axios.get(`http://localhost:5000/api/events/recommend/${user.id}`);
      setRecommendations(res.data.recommendations.filter(r => r.matchPercentage > 0).slice(0, 3));
    } catch (err) {
      console.error('Failed to load recommendations', err);
    }
  };

  const fetchMyEvents = async () => {
    try {
      const res = await axios.get(`http://localhost:5000/api/events/my-events/${user.id}`);
      setRegisteredIds(res.data.map(r => r.event._id));
    } catch (err) {
      console.error('Failed to load registrations', err);
    }
  };

  useEffect(() => {
    fetchEvents();
    fetchRecommendations();
    fetchMyEvents();
  }, []);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleCreate = async (e) => {
    e.preventDefault();
    setMessage('');
    try {
      const url = isExternal
        ? 'http://localhost:5000/api/events/external'
        : 'http://localhost:5000/api/events';

      await axios.post(url, {
        ...formData,
        createdBy: user.id
      });
      setMessage('Event created successfully');
      setFormData({ title: '', description: '', domain: '', department: '', date: '', time: '', venue: '', registrationLink: '', sourceName: '' });
      setIsExternal(false);
      setShowForm(false);
      fetchEvents();
    } catch (err) {
      setMessage('Failed to create event');
    }
  };

  const handleRegister = async (eventId) => {
    try {
      await axios.post(`http://localhost:5000/api/events/${eventId}/register`, {
        studentId: user.id
      });
      setRegisteredIds([...registeredIds, eventId]);
    } catch (err) {
      alert(err.response?.data?.message || 'Registration failed');
    }
  };

  const inputStyle = {
    width: '100%',
    padding: '10px 12px',
    borderRadius: '8px',
    border: '1px solid var(--color-border)',
    fontSize: '14px',
    marginBottom: '14px'
  };

  const formatDate = (dateStr) => {
    return new Date(dateStr).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
  };

  return (
    <Layout>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
        <div>
          <h1 style={{ fontSize: '24px', marginBottom: '4px' }}>Events</h1>
          <p style={{ color: 'var(--color-text-muted)', fontSize: '14px' }}>
            Workshops, hackathons, and symposiums — internal and external
          </p>
        </div>
        <button
          onClick={() => setShowForm(!showForm)}
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '8px',
            padding: '10px 16px',
            background: 'var(--color-accent)',
            color: '#fff',
            border: 'none',
            borderRadius: '8px',
            fontWeight: 600,
            fontSize: '14px'
          }}
        >
          <Plus size={16} />
          Create Event
        </button>
      </div>

      {recommendations.length > 0 && (
        <div style={{ marginBottom: '24px' }}>
          <h3 style={{ fontSize: '14px', marginBottom: '10px', color: 'var(--color-text-muted)' }}>
            Recommended for you
          </h3>
          <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap' }}>
            {recommendations.map((rec) => (
              <div key={rec.id} style={{
                background: '#FFF1E7',
                border: '1px solid #FFD9B8',
                borderRadius: '8px',
                padding: '10px 14px',
                fontSize: '13px',
                display: 'flex',
                alignItems: 'center',
                gap: '6px'
              }}>
                <Sparkles size={13} color="var(--color-accent)" />
                <strong>{rec.title}</strong> — {rec.matchPercentage}% match
              </div>
            ))}
          </div>
        </div>
      )}

      {showForm && (
        <div style={{
          background: 'var(--color-surface)',
          border: '1px solid var(--color-border)',
          borderRadius: '12px',
          padding: '20px',
          marginBottom: '24px',
          maxWidth: '480px'
        }}>
          <h3 style={{ fontSize: '15px', marginBottom: '16px' }}>New Event</h3>

          <label style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '13px', marginBottom: '14px', cursor: 'pointer' }}>
            <input
              type="checkbox"
              checked={isExternal}
              onChange={(e) => setIsExternal(e.target.checked)}
            />
            This is an external event (from another website, e.g. Unstop, a college, a government portal)
          </label>

          <form onSubmit={handleCreate}>
            <input name="title" placeholder="Event title" value={formData.title} onChange={handleChange} required style={inputStyle} />
            <input name="description" placeholder="Description" value={formData.description} onChange={handleChange} style={inputStyle} />
            <input name="domain" placeholder="Domain (e.g. AI, Web Dev)" value={formData.domain} onChange={handleChange} required style={inputStyle} />
            <input name="department" placeholder="Department (or 'All')" value={formData.department} onChange={handleChange} style={inputStyle} />
            <input type="date" name="date" value={formData.date} onChange={handleChange} required style={inputStyle} />
            <input name="time" placeholder="Time (e.g. 10:00 AM)" value={formData.time} onChange={handleChange} style={inputStyle} />
            <input name="venue" placeholder="Venue (e.g. Knowledge College, Seminar Hall)" value={formData.venue} onChange={handleChange} style={inputStyle} />

            {isExternal && (
              <>
                <input name="registrationLink" placeholder="Real registration link (e.g. https://unstop.com/...)" value={formData.registrationLink} onChange={handleChange} required={isExternal} style={inputStyle} />
                <input name="sourceName" placeholder="Source name (e.g. Unstop, Knowledge College)" value={formData.sourceName} onChange={handleChange} style={inputStyle} />
              </>
            )}

            {message && <p style={{ fontSize: '13px', marginBottom: '12px' }}>{message}</p>}
            <button type="submit" style={{ width: '100%', padding: '10px', background: 'var(--color-accent)', color: '#fff', border: 'none', borderRadius: '8px', fontWeight: 600, fontSize: '14px' }}>
              Create Event
            </button>
          </form>
        </div>
      )}

      <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
        {events.length === 0 && (
          <p style={{ color: 'var(--color-text-muted)', fontSize: '14px' }}>No events yet.</p>
        )}
        {events.map((ev) => (
          <div key={ev._id} style={{
            background: 'var(--color-surface)',
            border: '1px solid var(--color-border)',
            borderRadius: '12px',
            padding: '18px 20px',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center'
          }}>
            <div style={{ display: 'flex', gap: '14px', alignItems: 'flex-start' }}>
              <div style={{
                width: '40px',
                height: '40px',
                borderRadius: '8px',
                background: '#FFF1E7',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                flexShrink: 0
              }}>
                <CalendarDays size={18} color="var(--color-accent)" />
              </div>
              <div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <h3 style={{ fontSize: '15px' }}>{ev.title}</h3>
                  {ev.source === 'external' && (
                    <span style={{ fontSize: '11px', background: '#E7F1FF', color: '#1971C2', padding: '2px 8px', borderRadius: '6px' }}>
                      {ev.sourceName || 'External'}
                    </span>
                  )}
                </div>
                <p style={{ fontSize: '13px', color: 'var(--color-text-muted)', margin: '4px 0' }}>
                  {ev.domain} · {formatDate(ev.date)} {ev.time && `· ${ev.time}`}
                </p>
                {ev.venue && (
                  <p style={{ fontSize: '13px', color: 'var(--color-text-muted)', margin: '0 0 4px 0', display: 'flex', alignItems: 'center', gap: '4px' }}>
                    <MapPin size={13} />
                    {ev.venue}
                  </p>
                )}
                {ev.description && <p style={{ fontSize: '13px', margin: 0 }}>{ev.description}</p>}
              </div>
            </div>

            {ev.source === 'external' ? (
              <a
                href={ev.registrationLink}
                target="_blank"
                rel="noopener noreferrer"
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '6px',
                  padding: '8px 14px',
                  border: '1px solid var(--color-border)',
                  borderRadius: '8px',
                  fontSize: '13px',
                  textDecoration: 'none',
                  color: 'var(--color-text)',
                  whiteSpace: 'nowrap'
                }}
              >
                <ExternalLink size={14} />
                Register
              </a>
            ) : registeredIds.includes(ev._id) ? (
              <span style={{ fontSize: '13px', color: 'var(--color-success)', fontWeight: 600, whiteSpace: 'nowrap' }}>
                Registered
              </span>
            ) : (
              <button
                onClick={() => handleRegister(ev._id)}
                style={{
                  padding: '8px 14px',
                  border: '1px solid var(--color-border)',
                  borderRadius: '8px',
                  background: 'transparent',
                  fontSize: '13px',
                  whiteSpace: 'nowrap'
                }}
              >
                Register
              </button>
            )}
          </div>
        ))}
      </div>
    </Layout>
  );
}

export default Events;