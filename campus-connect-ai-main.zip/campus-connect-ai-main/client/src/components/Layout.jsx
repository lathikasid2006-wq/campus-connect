import Sidebar from './Sidebar';

function Layout({ children }) {
  return (
    <div style={{ display: 'flex' }}>
      <Sidebar />
      <div style={{ marginLeft: '240px', flex: 1, padding: '32px 40px', minHeight: '100vh' }}>
        {children}
      </div>
    </div>
  );
}

export default Layout;
