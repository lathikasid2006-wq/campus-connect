import { NavLink, useNavigate } from 'react-router-dom';
import { LayoutDashboard, BookOpen, Users, CalendarDays, LogOut } from 'lucide-react';

function Sidebar() {
  const navigate = useNavigate();
  const user = JSON.parse(localStorage.getItem('user'));

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    navigate('/login');
  };

  const navItems = [
    { to: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { to: '/resources', label: 'Resource Hub', icon: BookOpen },
    { to: '/projects', label: 'Team Finder', icon: Users },
    { to: '/events', label: 'Events', icon: CalendarDays },
  ];

  return (
    <div style={{
      width: '240px',
      minHeight: '100vh',
      background: 'var(--color-sidebar)',
      color: '#fff',
      display: 'flex',
      flexDirection: 'column',
      padding: '24px 16px',
      position: 'fixed',
      left: 0,
      top: 0
    }}>
      <h2 style={{ color: '#fff', fontSize: '20px', marginBottom: '32px', paddingLeft: '8px' }}>
        Campus Connect
      </h2>

      <nav style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: '4px' }}>
        {navItems.map((item) => {
          const Icon = item.icon;
          return (
            <NavLink
              key={item.to}
              to={item.to}
              style={({ isActive }) => ({
                display: 'flex',
                alignItems: 'center',
                gap: '10px',
                padding: '10px 12px',
                borderRadius: '8px',
                color: isActive ? 'var(--color-sidebar)' : '#E5E7EB',
                background: isActive ? 'var(--color-accent)' : 'transparent',
                textDecoration: 'none',
                fontSize: '14px',
                fontWeight: isActive ? 600 : 500,
                transition: 'background 0.15s'
              })}
            >
              <Icon size={18} />
              {item.label}
            </NavLink>
          );
        })}
      </nav>

      <div style={{ borderTop: '1px solid #2A3A5C', paddingTop: '16px', marginTop: '16px' }}>
        <p style={{ fontSize: '13px', color: '#9CA3AF', margin: '0 0 4px 8px' }}>
          {user?.name}
        </p>
        <button
          onClick={handleLogout}
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '10px',
            width: '100%',
            padding: '10px 12px',
            borderRadius: '8px',
            border: 'none',
            background: 'transparent',
            color: '#E5E7EB',
            fontSize: '14px',
            textAlign: 'left'
          }}
        >
          <LogOut size={18} />
          Logout
        </button>
      </div>
    </div>
  );
}

export default Sidebar;
