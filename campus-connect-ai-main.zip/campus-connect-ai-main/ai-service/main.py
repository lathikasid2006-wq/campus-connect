from fastapi import FastAPI
from pydantic import BaseModel
from typing import List
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

app = FastAPI()

@app.get("/")
def home():
    return {"message": "Campus Connect AI service is running!"}


# ---- Team Recommendation ----

class Student(BaseModel):
    id: str
    name: str
    skills: List[str]

class MatchRequest(BaseModel):
    requiredSkills: List[str]
    students: List[Student]

@app.post("/recommend-team")
def recommend_team(request: MatchRequest):
    project_text = " ".join(request.requiredSkills)
    student_texts = [" ".join(student.skills) for student in request.students]

    all_texts = [project_text] + student_texts

    vectorizer = TfidfVectorizer()
    tfidf_matrix = vectorizer.fit_transform(all_texts)

    similarity_scores = cosine_similarity(tfidf_matrix[0:1], tfidf_matrix[1:])[0]

    results = []
    for i, student in enumerate(request.students):
        results.append({
            "id": student.id,
            "name": student.name,
            "matchPercentage": round(similarity_scores[i] * 100, 2)
        })

    results.sort(key=lambda x: x["matchPercentage"], reverse=True)

    return {"recommendations": results}


# ---- Resource Recommendation ----

class ResourceItem(BaseModel):
    id: str
    title: str
    subject: str

class ResourceRecommendRequest(BaseModel):
    studentInterests: List[str]
    resources: List[ResourceItem]

@app.post("/recommend-resources")
def recommend_resources(request: ResourceRecommendRequest):
    student_text = " ".join(request.studentInterests)
    resource_texts = [f"{r.title} {r.subject}" for r in request.resources]

    all_texts = [student_text] + resource_texts

    vectorizer = TfidfVectorizer()
    tfidf_matrix = vectorizer.fit_transform(all_texts)

    similarity_scores = cosine_similarity(tfidf_matrix[0:1], tfidf_matrix[1:])[0]

    results = []
    for i, resource in enumerate(request.resources):
        results.append({
            "id": resource.id,
            "title": resource.title,
            "matchPercentage": round(similarity_scores[i] * 100, 2)
        })

    results.sort(key=lambda x: x["matchPercentage"], reverse=True)

    return {"recommendations": results}


# ---- Event Recommendation ----

class EventItem(BaseModel):
    id: str
    title: str
    domain: str

class EventRecommendRequest(BaseModel):
    studentInterests: List[str]
    events: List[EventItem]

@app.post("/recommend-events")
def recommend_events(request: EventRecommendRequest):
    student_text = " ".join(request.studentInterests)
    event_texts = [f"{e.title} {e.domain}" for e in request.events]

    all_texts = [student_text] + event_texts

    vectorizer = TfidfVectorizer()
    tfidf_matrix = vectorizer.fit_transform(all_texts)

    similarity_scores = cosine_similarity(tfidf_matrix[0:1], tfidf_matrix[1:])[0]

    results = []
    for i, event in enumerate(request.events):
        results.append({
            "id": event.id,
            "title": event.title,
            "matchPercentage": round(similarity_scores[i] * 100, 2)
        })

    results.sort(key=lambda x: x["matchPercentage"], reverse=True)

    return {"recommendations": results}