const express = require('express');
const Event = require('../models/Event');
const EventRegistration = require('../models/EventRegistration');

const router = express.Router();
const axios = require('axios');
const User = require('../models/User');

// CREATE an event (admin creates internal event)
router.post('/', async (req, res) => {
  try {
    const { title, description, domain, department, date, time,venue, createdBy } = req.body;

    const newEvent = new Event({
      title,
      description,
      domain,
      department,
      date,
      time,
      venue,
      createdBy,
      source: 'internal'
    });

    await newEvent.save();

    res.status(201).json({ message: 'Event created successfully', event: newEvent });

  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});
// CREATE an external event (admin manually adds hackathon/symposium from another site)
router.post('/external', async (req, res) => {
  try {
    const { title, description, domain, department, date, time,venue, registrationLink, sourceName } = req.body;

    const newEvent = new Event({
      title,
      description,
      domain,
      department,
      date,
      time,
      venue,
      registrationLink,
      sourceName,
      source: 'external'
    });

    await newEvent.save();

    res.status(201).json({ message: 'External event added successfully', event: newEvent });

  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// LIST all events (internal + external), soonest first
router.get('/', async (req, res) => {
  try {
    const events = await Event.find().sort({ date: 1 });
    res.status(200).json(events);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// REGISTER for an event
router.post('/:eventId/register', async (req, res) => {
  try {
    const { studentId } = req.body;
    const { eventId } = req.params;

    const existing = await EventRegistration.findOne({ event: eventId, student: studentId });
    if (existing) {
      return res.status(400).json({ message: 'Already registered for this event' });
    }

    const registration = new EventRegistration({ event: eventId, student: studentId });
    await registration.save();

    res.status(201).json({ message: 'Registered successfully', registration });

  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// LIST a student's registered events
router.get('/my-events/:studentId', async (req, res) => {
  try {
    const registrations = await EventRegistration.find({ student: req.params.studentId })
      .populate('event');

    res.status(200).json(registrations);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});
//const axios = require('axios');
//const User = require('../models/User');

// GET AI-recommended events for a student
router.get('/recommend/:studentId', async (req, res) => {
  try {
    const student = await User.findById(req.params.studentId);
    if (!student) {
      return res.status(404).json({ message: 'Student not found' });
    }

    const allEvents = await Event.find();

    const eventData = allEvents.map(e => ({
      id: e._id.toString(),
      title: e.title,
      domain: e.domain
    }));

    const aiResponse = await axios.post('http://127.0.0.1:8000/recommend-events', {
      studentInterests: student.interests,
      events: eventData
    });

    res.status(200).json(aiResponse.data);

  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

module.exports = router;