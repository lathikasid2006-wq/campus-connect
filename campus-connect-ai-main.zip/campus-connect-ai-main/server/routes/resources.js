const express = require('express');
const multer = require('multer');
const path = require('path');
const Resource = require('../models/Resource');
const axios = require('axios');
const User = require('../models/User');

const router = express.Router();

// Configure where and how files get saved
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/');
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + '-' + file.originalname);
  }
});

const upload = multer({ storage: storage });

// UPLOAD route
router.post('/upload', upload.single('file'), async (req, res) => {
  try {
    const { title, subject, semester } = req.body;

    const newResource = new Resource({
      title,
      subject,
      semester,
      fileName: req.file.originalname,
      filePath: req.file.path
    });

    await newResource.save();

    res.status(201).json({ message: 'Resource uploaded successfully', resource: newResource });

  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// LIST all resources
router.get('/', async (req, res) => {
  try {
    const resources = await Resource.find().sort({ createdAt: -1 });
    res.status(200).json(resources);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// GET AI-recommended resources for a student (based on their profile interests)
router.get('/recommend/:studentId', async (req, res) => {
  try {
    const student = await User.findById(req.params.studentId);
    if (!student) {
      return res.status(404).json({ message: 'Student not found' });
    }

    const allResources = await Resource.find();

    const resourceData = allResources.map(r => ({
      id: r._id.toString(),
      title: r.title,
      subject: r.subject
    }));

    const aiResponse = await axios.post('http://127.0.0.1:8000/recommend-resources', {
      studentInterests: student.interests,
      resources: resourceData
    });

    res.status(200).json(aiResponse.data);

  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// SEARCH-based AI recommendation (student types a topic, e.g. "ML")
router.post('/search', async (req, res) => {
  try {
    const { query } = req.body;

    if (!query || query.trim() === '') {
      return res.status(400).json({ message: 'Search query is required' });
    }

    const allResources = await Resource.find();

    const resourceData = allResources.map(r => ({
      id: r._id.toString(),
      title: r.title,
      subject: r.subject
    }));

    const aiResponse = await axios.post('http://127.0.0.1:8000/recommend-resources', {
      studentInterests: [query],
      resources: resourceData
    });

    res.status(200).json(aiResponse.data);

  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// DOWNLOAD a specific resource by ID
router.get('/download/:id', async (req, res) => {
  try {
    const resource = await Resource.findById(req.params.id);
    if (!resource) {
      return res.status(404).json({ message: 'Resource not found' });
    }
    res.download(resource.filePath, resource.fileName);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

module.exports = router;