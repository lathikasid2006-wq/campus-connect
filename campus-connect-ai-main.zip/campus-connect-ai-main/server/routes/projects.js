const express = require('express');
const axios = require('axios');
const Project = require('../models/Project');
const JoinRequest = require('../models/JoinRequest');
const User = require('../models/User');

const router = express.Router();

// CREATE a new project post
router.post('/', async (req, res) => {
  try {
    const { title, description, requiredSkills, postedBy } = req.body;

    const newProject = new Project({
      title,
      description,
      requiredSkills,
      postedBy
    });

    await newProject.save();

    res.status(201).json({ message: 'Project posted successfully', project: newProject });

  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// LIST all projects
router.get('/', async (req, res) => {
  try {
    const projects = await Project.find()
      .populate('postedBy', 'name email department')
      .sort({ createdAt: -1 });

    res.status(200).json(projects);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// POSTER invites a specific student to join
router.post('/:projectId/invite', async (req, res) => {
  try {
    const { studentId } = req.body;
    const { projectId } = req.params;

    const existing = await JoinRequest.findOne({ project: projectId, student: studentId });
    if (existing) {
      return res.status(400).json({ message: 'A request or invite already exists for this student' });
    }

    const newInvite = new JoinRequest({
      project: projectId,
      student: studentId,
      initiatedBy: 'poster'
    });

    await newInvite.save();

    res.status(201).json({ message: 'Invite sent successfully', invite: newInvite });

  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// SEND a join request
router.post('/:projectId/join', async (req, res) => {
  try {
    const { studentId } = req.body;
    const { projectId } = req.params;

    const existing = await JoinRequest.findOne({ project: projectId, student: studentId });
    if (existing) {
      return res.status(400).json({ message: 'You already requested to join this project' });
    }

    const newRequest = new JoinRequest({
      project: projectId,
      student: studentId
    });

    await newRequest.save();

    res.status(201).json({ message: 'Join request sent successfully', request: newRequest });

  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// LIST all join requests for a specific project (so the project owner can see who wants to join)
router.get('/:projectId/requests', async (req, res) => {
  try {
    const requests = await JoinRequest.find({ project: req.params.projectId })
      .populate('student', 'name email skills department');

    res.status(200).json(requests);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// LIST all invites sent to a specific student (from posters)
router.get('/invites/:studentId', async (req, res) => {
  try {
    const invites = await JoinRequest.find({
      student: req.params.studentId,
      initiatedBy: 'poster',
      status: 'pending'
    }).populate('project', 'title description requiredSkills');

    res.status(200).json(invites);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// LIST requests the student sent, that were just accepted/rejected and not yet seen
router.get('/notifications/:studentId', async (req, res) => {
  try {
    const notifications = await JoinRequest.find({
      student: req.params.studentId,
      initiatedBy: { $ne: 'poster' },
      status: { $in: ['accepted', 'rejected'] },
      acknowledged: { $ne: true }
    }).populate('project', 'title');

    res.status(200).json(notifications);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// MARK a notification as seen
router.put('/notifications/:requestId/seen', async (req, res) => {
  try {
    await JoinRequest.findByIdAndUpdate(req.params.requestId, { acknowledged: true });
    res.status(200).json({ message: 'Marked as seen' });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// ACCEPT or REJECT a join request
router.put('/requests/:requestId', async (req, res) => {
  try {
    const { status } = req.body; // expects "accepted" or "rejected"

    const updatedRequest = await JoinRequest.findByIdAndUpdate(
      req.params.requestId,
      { status },
      { new: true }
    );

    if (!updatedRequest) {
      return res.status(404).json({ message: 'Join request not found' });
    }

    res.status(200).json({ message: `Request ${status}`, request: updatedRequest });

  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// GET AI-recommended students for a project
router.get('/:projectId/recommend', async (req, res) => {
  try {
    const project = await Project.findById(req.params.projectId);
    if (!project) {
      return res.status(404).json({ message: 'Project not found' });
    }

    const students = await User.find({ role: 'student', _id: { $ne: project.postedBy } });

    const studentData = students.map(s => ({
      id: s._id.toString(),
      name: s.name,
      skills: s.skills
    }));

    const aiResponse = await axios.post('http://127.0.0.1:8000/recommend-team', {
      requiredSkills: project.requiredSkills,
      students: studentData
    });

    res.status(200).json(aiResponse.data);

  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

module.exports = router;