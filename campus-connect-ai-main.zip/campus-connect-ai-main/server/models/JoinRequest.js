const mongoose = require('mongoose');

const joinRequestSchema = new mongoose.Schema({
  project: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Project',
    required: true
  },
  student: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  status: {
    type: String,
    enum: ['pending', 'accepted', 'rejected'],
    default: 'pending'
  },
  initiatedBy: {
    type: String,
    enum: ['student', 'poster'],
    default: 'student'
  },
  acknowledged: {
    type: Boolean,
    default: false
  }
}, { timestamps: true });

module.exports = mongoose.model('JoinRequest', joinRequestSchema);