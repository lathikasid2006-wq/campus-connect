const mongoose = require('mongoose');

const eventSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true
  },
  description: {
    type: String
  },
  domain: {
    type: String,
    required: true
  },
  department: {
    type: String,
    default: 'All'
  },
  date: {
    type: Date,
    required: true
  },
  time: {
    type: String
  },
  venue: {
    type: String
  },
  registrationLink: {
    type: String
  },
  source: {
    type: String,
    enum: ['internal', 'external'],
    default: 'internal'
  },
  sourceName: {
    type: String
  },
  createdBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  }
}, { timestamps: true });

module.exports = mongoose.model('Event', eventSchema);